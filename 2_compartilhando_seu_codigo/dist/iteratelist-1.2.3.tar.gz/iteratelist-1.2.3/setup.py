from distutils.core import setup


setup(
    name = 'iteratelist',
    version = '1.2.3',
    py_modules = ['iteratelist'],
    author = 'wmfinamore',
    author_email = 'finamore.wm@gmail.com',
    description = 'A simple printer of nested lists',
)

# No prompt de comando usar > setup.py sdist

# Em seguida, para instalar use > setup.py install